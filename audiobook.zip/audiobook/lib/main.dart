import 'dart:ui';
import 'dart:io'; // For file picker
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:file_picker/file_picker.dart'; // For picking audio files
import 'package:just_audio/just_audio.dart'; // For audio playback

void main() {
  runApp(AudiobookApp());
}

class AudiobookApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Royal Audiobook Player',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.deepPurple[800],
        textTheme: GoogleFonts.playfairDisplayTextTheme(), // Royal-looking font
      ),
      home: AudiobookPlayerScreen(),
    );
  }
}

class AudiobookPlayerScreen extends StatefulWidget {
  @override
  _AudiobookPlayerScreenState createState() => _AudiobookPlayerScreenState();
}

class _AudiobookPlayerScreenState extends State<AudiobookPlayerScreen> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  List<Map<String, String>> _songs = [
    {
      'title': 'Ayodha Pooja',
      'author': 'Anirudh',
      'image': 'https://tse4.mm.bing.net/th?id=OIP.qISBLxZV9_uZCT9uH3RjjgHaHa&pid=Api&P=0&h=180',
      'file': 'song.url', // Placeholder
    },
    {
      'title': 'Leharyi',
      'author': 'Sid SriRam',
      'image': 'https://tse3.mm.bing.net/th?id=OIP.gr9WqL2A3jDqRgdVC2En-AHaHa&pid=Api&P=0&h=180',
      'file': 'song.url', // Placeholder
    },
  ];

  int _currentSongIndex = 0;
  bool _isPlaying = false;
  Duration _currentPosition = Duration.zero;
  Duration _songDuration = Duration.zero;

  void _playPause() async {
    if (_isPlaying) {
      await _audioPlayer.pause();
    } else {
      String? filePath = _songs[_currentSongIndex]['file'];
      if (filePath != null && filePath.isNotEmpty) {
        await _audioPlayer.setFilePath(filePath);
        await _audioPlayer.play();
      }
    }
    setState(() {
      _isPlaying = !_isPlaying;
    });
  }

  void _nextSong() {
    _stopCurrentSong();
    setState(() {
      _currentSongIndex = (_currentSongIndex + 1) % _songs.length;
    });
    _playPause();
  }

  void _previousSong() {
    _stopCurrentSong();
    setState(() {
      _currentSongIndex =
          (_currentSongIndex - 1 + _songs.length) % _songs.length;
    });
    _playPause();
  }

  void _stopCurrentSong() async {
    await _audioPlayer.stop();
    setState(() {
      _isPlaying = false;
      _currentPosition = Duration.zero;
      _songDuration = Duration.zero;
    });
  }

  void _addSong() async {
    FilePickerResult  result = await FilePicker.platform.pickFiles(
      type: FileType.audio,
    );

    if (result != null) {
      File file = File(result.files.single.path!);
      setState(() {
        _songs.add({
          'title': 'New Audiobook ${_songs.length + 1}',
          'author': 'Unknown',
          'image': 'https://via.placeholder.com/150', // Placeholder image
          'file': file.path,
        });
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _audioPlayer.positionStream.listen((position) {
      setState(() {
        _currentPosition = position;
      });
    });

    _audioPlayer.durationStream.listen((duration) {
      setState(() {
        _songDuration = duration ?? Duration.zero;
      });
    });
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Audiobook',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.deepPurple[800],
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.add, color: Colors.white),
            onPressed: _addSong,
          )
        ],
      ),
      body: Stack(
        children: [
          // Background Image with Blur Effect
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage(
                  _songs[_currentSongIndex]['image']!,
                ),
                fit: BoxFit.cover,
              ),
            ),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(
                color: Colors.black.withOpacity(0.3),
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Audiobook Cover
                Container(
                  width: 200,
                  height: 300,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black54,
                        blurRadius: 10,
                        offset: Offset(0, 4),
                      ),
                    ],
                    image: DecorationImage(
                      image: NetworkImage(
                        _songs[_currentSongIndex]['image']!,
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(height: 20),
                // Audiobook Title
                Text(
                  _songs[_currentSongIndex]['title']!,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.amber[200],
                  ),
                ),
                SizedBox(height: 10),
                // Author
                Text(
                  'by ${_songs[_currentSongIndex]['author']!}',
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.amber[100],
                  ),
                ),
                SizedBox(height: 30),
                // Playback Controls
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back),
                      iconSize: 36,
                      color: Colors.amber[200],
                      onPressed: _previousSong,
                    ),
                    SizedBox(width: 20),
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.amber[200],
                      child: IconButton(
                        icon: Icon(_isPlaying ? Icons.pause : Icons.play_arrow),
                        iconSize: 36,
                        color: Colors.deepPurple[800],
                        onPressed: _playPause,
                      ),
                    ),
                    SizedBox(width: 20),
                    IconButton(
                      icon: Icon(Icons.arrow_forward),
                      iconSize: 36,
                      color: Colors.amber[200],
                      onPressed: _nextSong,
                    ),
                  ],
                ),
                SizedBox(height: 40),
                // Progress Bar (Slider)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30.0),
                  child: Column(
                    children: [
                      Slider(
                        value: _currentPosition.inSeconds.toDouble(),
                        min: 0,
                        max: _songDuration.inSeconds.toDouble(),
                        activeColor: Colors.amber[200],
                        inactiveColor: Colors.deepPurple[300],
                        onChanged: (value) async {
                          await _audioPlayer.seek(Duration(seconds: value.toInt()));
                        },
                      ),
                      SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            '${_currentPosition.inMinutes}:${(_currentPosition.inSeconds % 60).toString().padLeft(2, '0')}',
                            style: TextStyle(color: Colors.amber[100]),
                          ),
                          Text(
                            '${_songDuration.inMinutes}:${(_songDuration.inSeconds % 60).toString().padLeft(2, '0')}',
                            style: TextStyle(color: Colors.amber[100]),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class FilePickerResult {
}

class AudioPlayer {
}
